import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(TodoApp());
}


//*앱의 시작 지점
class TodoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TodoHomePage(),
    );
  }
}

//*할 일을 추가/삭제하면 상태 변경
class TodoHomePage extends StatefulWidget {
  @override
  _TodoHomePageState createState() => _TodoHomePageState();
}

class _TodoHomePageState extends State<TodoHomePage> {
  List<String> _todoItems = []; // 할 일 목록

  @override
  void initState() {
    super.initState();
    _loadTodoList(); // 앱 시작 시 저장된 목록 불러오기
  }

  // 저장된 데이터 불러오기
  Future<void> _loadTodoList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _todoItems = prefs.getStringList('todoList') ?? [];
    });
  }

  // *sharedpreferences 사용한 데이터저장
  Future<void> _saveTodoList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('todoList', _todoItems);
  }

  // 할 일 추가
  void _addTodoItem(String item) {
    if (item.isEmpty) return; // 빈 입력 방지
    setState(() {
      _todoItems.add(item);
    });
    _saveTodoList();
  }

  // 할 일 삭제
  void _deleteTodoItem(int index) {
    setState(() {
      _todoItems.removeAt(index);
    });
    _saveTodoList();
  }

  // 할 일 추가하는 다이얼로그 표시
  void _showAddTodoDialog() {
    TextEditingController _textFieldController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('새로운 일 추가'),
          content: TextField(
            controller: _textFieldController,
            autofocus: true,
            decoration: InputDecoration(hintText: '입력하세요'),
          ),
          actions: [
            TextButton(
              child: Text('취소'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('추가'),
              onPressed: () {
                String task = _textFieldController.text.trim();
                if (task.isNotEmpty) {
                  _addTodoItem(task);
                }
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
      ),
      body: _todoItems.isEmpty
          ? Center(
        child: Text(
          '오늘의 일정을 추가해주세요!',
          style: TextStyle(fontSize: 18),
        ),
      )
          : ListView.builder(
        itemCount: _todoItems.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_todoItems[index]),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () => _deleteTodoItem(index),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTodoDialog,
        child: Icon(Icons.add),
      ),
    );
  }
}